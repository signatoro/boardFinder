from enum import Enum

class Location_Type(Enum):
    IN_PERSON = 'in-person'
    ONLINE = 'online'

